#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Package for our analysis
library(dplyr)
library(tidyr)
library(sp)
library(rgdal)
library(berryFunctions)
library(RColorBrewer)
library(maptools)

#Data 
#  Map
sfbs.pg.5bays <- readOGR(dsn = ".", layer = "sfbs_pg_5bays")

# Predictions
pred.data <- read.csv("mwt.ot.all.pred.csv", header = TRUE)

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Predicted Probabilities"),
  
   # Sidebar with a slider input for years and months
  sidebarLayout(
    sidebarPanel(
      sliderInput("cohort",
                  "Year",
                  min = 1987,
                  max = 2013,
                  value = 1987,
                  step = 1),
      sliderInput("month36",
                  "Month",
                  min = 1,
                  max = 36,
                  value = 5,
                  step = 1,
                  round = FALSE),
      radioButtons("radio", h3("Trawl"),
                   choices = list("Midwater Trawl" = 1, "Otter Trawl" = 2)),
      plotOutput("legPlot")
    ),

    # Show a plot of the generated distribution
    mainPanel(
      plotOutput("distPlot", height = "650", width = "650")
      )
    )
)



# Define server logic required to draw a histogram
server <- function(input, output) {
   
   output$distPlot <- renderPlot({
     par(mar = c(0.1, 0.1, 0.3, 0.1))
     print(plot(sfbs.pg.5bays, 
          #main = month.name[i],
          bty = "o",
          lwd = 2,
          col = c(brewer.pal(9, "YlGnBu"), "black")[classify(if (input$radio == 1) pred.data$fit.mwt else pred.data$fit.ot, 
                                                             method = "usergiven", 
                                                             breaks = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1))$index[which(pred.data$cohort == input$cohort & 
                                                                                                                                          pred.data$month36 == input$month36)]]))
    text(coordinates(sfbs.pg.5bays), labels = as.character(sfbs.pg.5bays@data$reg_name), 
         pos = c(4, 4, 3, 1, 3), 
         offset = 5.7,
         cex = 1.5) 
   })
   output$legPlot <- renderPlot({
     par(mar = c(0.1, 0.1, 0.1, 0.1),
         oma = c(0.1, 0.1, 0.1, 0.1))
     plot(0, 0, type="n",
          xlim = c(1987, 2015),
          ylim = c(0, 1),
          bty = "n",
          ylab = "",
          xlab = "", 
          xaxt="n", yaxt="n")
     legend("center", 
            title = "Legend",
            legend = rev(c("<0.1", "0.1-0.2", "0.2-0.3", "0.3-0.4", "0.4-0.5", "0.5-0.6", "0.6-0.7", "0.7-0.8", "0.8-0.9", "0.9-1")), 
            fill=rev(c(brewer.pal(9, "YlGnBu"), "black")),
            horiz = FALSE)
   })
}

# Run the application 
shinyApp(ui = ui, server = server)

